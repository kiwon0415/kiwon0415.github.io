# 알트시즌 내비게이터 홈페이지 스타터 배포 가이드

## 빠른 배포
- Vercel/Netlify에 이 폴더를 업로드 → 도메인 연결

## 결제 연동(개요)
1) 백엔드(/api)
   - POST /api/checkout: 결제 세션 생성 (토스/포트원 등)
   - POST /api/webhook: 결제 성공 수신 → 라이선스 키 생성/저장 → 이메일 발송
   - POST /api/download: (email, key, platform) 검증 → S3/Storage 서명 URL 발급
2) 프런트
   - index.html 구매 버튼 → /js/checkout.js 참고

## 라이선스 설계(추천)
- licenses(id,email,plan,key,status,created_at,expires_at)
- activations(license_id, device_hash, created_at)

## 법적 고지
- /terms.html, /privacy.html, /refund.html에 고지
