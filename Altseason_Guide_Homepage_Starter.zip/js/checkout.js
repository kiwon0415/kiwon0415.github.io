// /js/checkout.js — 결제 연동 가이드 (데모)
document.querySelectorAll('.checkout-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const plan = btn.getAttribute('data-plan');
    alert('데모 결제: ' + plan + '\n실제 결제는 /api/checkout 연동이 필요합니다.');
  });
});
